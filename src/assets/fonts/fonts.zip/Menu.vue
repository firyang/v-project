<template>
	<div class="es-menu-bar">
        <i class="iconfont icon-liebiao" @mouseover="handleMouseover"></i>
        <h2>My Work Space</h2>
        <div class="es-menu" @mouseleave="handleMouseleave">
            <div class="es-menu-left">
                <ul>
                    <li class="active" @click="handleClick">My Menu <i class="iconfont icon-jiantou"></i></li>
                    <li @click="handleClick">My Work Space <i class="iconfont icon-jiantou"></i></li>
                    <li @click="handleClick">Oppuity <i class="iconfont icon-jiantou"></i></li>
                    <li @click="handleClick">SPQ <i class="iconfont icon-jiantou"></i></li>
                </ul>
            </div>
            <div class="es-menu-right">                    
                <ul>
                    <li class="active">
                        <dl>
                            <dt>gggggggg</dt>
                            <dd><a href="#">hhhhhhhh</a><i class="iconfont icon-iconfontxingxing" @click="handleCheck"></i></dd>
                            <dd><a href="#">kkkkkkkkkkkk</a><i class="iconfont icon-ge_xingji" @click="handleCheck"></i></dd>
                            <dd><a href="#">lllllllllll</a><i class="iconfont icon-ge_xingji" @click="handleCheck"></i></dd>
                            <dd><a href="#">hhhhhhhh</a><i class="iconfont icon-ge_xingji" @click="handleCheck"></i></dd>
                            <dd><a href="#">kkkkkkkkkkkk</a><i class="iconfont icon-ge_xingji" @click="handleCheck"></i></dd>
                            <dd><a href="#">lllllllllll</a><i class="iconfont icon-ge_xingji" @click="handleCheck"></i></dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                    </li>                        
                    <li>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                    </li>                        
                    <li>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                    </li>                        
                    <li>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                        <dl>
                            <dt>gggggggg</dt>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                            <dd>hhhhhhhh</dd>
                            <dd>kkkkkkkkkkkk</dd>
                            <dd>lllllllllll</dd>
                        </dl>
                    </li>
                </ul>
            </div>         
        </div>        
    </div>
</template>

<script>
	export default{
		data(){
			return {
				list:[]
			}
        },
        methods:{
            handleClick(e){
                let $tar = $(e.target),
                    rightMenu = $('.es-menu-right>ul>li')
                $tar.addClass('active').siblings().removeClass('active')
                rightMenu.eq($tar.index()).addClass('active').siblings().removeClass('active')
            },
            handleMouseover(e){
                $(e.target).addClass('rotate').siblings('.es-menu').css({
                    display: 'flex',
                    justifyContent: 'space-between'
                })
            },
            handleMouseleave(e){
                $(e.target).hide().siblings('.icon-liebiao').removeClass('rotate')
            },
            handleCheck(e){
                let $tar = $(e.target)
                if($tar.hasClass('icon-ge_xingji')){
                    $tar.removeClass('icon-ge_xingji').addClass('icon-iconfontxingxing')
                }else{
                    $tar.removeClass('icon-iconfontxingxing').addClass('icon-ge_xingji')
                }
            }
        }
	}
</script>
<style>
ul,dl{
    list-style: none;
    margin: 0;
    padding: 0;
}
.es-menu-bar{
    width: 100%;
    height: 46px;
    background: #091120;
    position: relative;
    text-align: left;
	/* perspective: 1800px;
	transform-style:preserve-3d;
    transform:rotateY(180deg);
	backface-visibility:hidden; */
}

/* 菜单图标 icon */ 
.es-menu-bar>.icon-liebiao{
    color: #ffffff;
    font-size: 2.2em;
    line-height: 46px;
    cursor: pointer;
    margin-left: 20px;
}
.es-menu-bar>.icon-liebiao.rotate{
    display: inline-block;
    transform:rotate(90deg);
}

/* 页面标题 */ 
.es-menu-bar>h2{
    font-size: 1em;
    color: #ffffff;
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
}

.es-menu-bar>.es-menu{
    display: none;
    /* justify-content: space-between; */
}

/* 左侧一级菜单 */ 
.es-menu-bar>.es-menu>.es-menu-left{
    width: 16%;
    min-width: 180px;
    text-align: left;
    background: #091120;
    color: #ffffff;
}
.es-menu-bar>.es-menu>.es-menu-left>ul>li{
    line-height: 40px;
    padding: 0 20px;
}
.es-menu-bar>.es-menu>.es-menu-left>ul>li:hover,
.es-menu-bar>.es-menu>.es-menu-left>ul>li.active{
    background: #0f1f41;
    color:  #3c6fd4;;
}
.es-menu-bar>.es-menu>.es-menu-left>ul>li>.iconfont{
    font-size: 0.6em;
    float: right;
}

/* 右侧子菜单 */ 
.es-menu-bar>.es-menu>.es-menu-right{
    width: 84%;
    text-align: left;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li{
    width: 100%;
    padding: 0 30px 20px;
    display: none;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li.active{
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li>dl{
    width:50%;
    padding-top: 10px;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li>dl>dt{
    border-bottom: 1px solid #CCC;
    line-height: 40px;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li>dl>dd{
    line-height: 26px;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li>dl>dd>.icon-ge_xingji{
    margin-left: 16px;
    font-size: 1.5em;
    color: #ddd;
    cursor: pointer;
}
.es-menu-bar>.es-menu>.es-menu-right>ul>li>dl>dd>.icon-iconfontxingxing{
    margin-left: 16px;
    font-size: 1.3em;
    color: #709bf0;
    cursor: pointer;
}
@media all and (max-width:767px){
    .es-menu-bar>.es-menu>.es-menu-right>ul>li>dl{
        width: 100%;
    }
}
</style>
